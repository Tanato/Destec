﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Destec.CoreApi.Migrations
{
    public partial class v002 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ExternalCode",
                table: "Kits",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_TarefaAssociadas_KitId",
                table: "TarefaAssociadas",
                column: "KitId");

            //migrationBuilder.AddForeignKey(
            //    name: "FK_TarefaAssociadas_Kits_KitId",
            //    table: "TarefaAssociadas",
            //    column: "KitId",
            //    principalTable: "Kits",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_TarefaAssociadas_Kits_KitId",
            //    table: "TarefaAssociadas");

            //migrationBuilder.DropIndex(
            //    name: "IX_TarefaAssociadas_KitId",
            //    table: "TarefaAssociadas");

            //migrationBuilder.DropColumn(
            //    name: "ExternalCode",
            //    table: "Kits");
        }
    }
}
